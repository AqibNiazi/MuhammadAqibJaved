module.exports = {
  HomeServices: require("./home"),
  MenCollectionServices: require("./menCollection"),
  womenCollectionService: require("./womenCollection"),
  winterCollectionService: require("./winterCollection"),
  summerCollectionSevice: require("./summerCollection"),
  childrenCollectionService: require("./childrenCollection"),
  loginService: require("./login"),
  signUpService: require("./signUp"),
};
