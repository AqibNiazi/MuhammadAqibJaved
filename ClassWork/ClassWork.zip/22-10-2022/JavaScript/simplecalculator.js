function add(num1,num2){
    let result=parseInt(num1)+parseInt(num2);
   document.getElementById("res").innerHTML=result;
  }
  function subtract(num1,num2){
   let result=parseInt(num1)-parseInt(num2);
   document.getElementById("res").innerHTML=result;
  }
