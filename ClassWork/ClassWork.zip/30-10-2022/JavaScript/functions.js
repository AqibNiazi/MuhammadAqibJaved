//                                                      Simple functions


function fullName(fname,lname){
return fname+lname+" Niazi"
}
console.log(fullName("Aqib"," Javed"));


//                                                      arrow functions

const fullName=(fname,lname)=>{
    return fname+lname+" Niazi"

}
console.log(fullName("Aqib"," Javed"));
