const checkSum=(arr,num)=>{

}
checkSum([1,5,1,4,8],9)