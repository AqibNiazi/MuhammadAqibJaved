//                                                  Function                                        //

// function twoTable(){
//     let num=2;
//     for(let i=0;i<=10;i++){
     
//         console.log(`${num} * ${i}= ${num*i}`);
//     }
   
// }
// twoTable();

// const student={
//     name:"M Aqib javed",
//     stu_address:"Chakwal",
//     Degree:"BS Software Engineer",
//     phone_nO:"03081177825",
//     address:{
//         city:"Taxila"
//     }
// }
// console.log(` Student Name : ${student.name} \n Student Address : ${student.stu_address} \n Student Degree : ${student.Degree} \n Phone Number :${student.phone_nO}`);
// console.log(student["address"]["city"]);


//                                                   Objects                            //


// const employee={
//     employeeId:'18-SE-50',
//     employeeName:'M Aqib Javed', 
//      employeeCompany:'UET Taxila', 
//       employeeCompanyAddress:{
//         city:'Taxila',
//         country:'Pakistan'
//       },
//       employeeAddress:{
//         city:'Chakwal',
//         country:'Pakistan'
//       },
//       employeeSalary:'50000'
// }
// console.log(`Employee Company Address :${employee.employeeCompanyAddress.city}`);
// console.log(`Employee  Address :${employee.employeeAddress.city}`);



//                                       Arrays                            //



const arr=["Aqib","Javed","Niazi"]
console.log(arr);
