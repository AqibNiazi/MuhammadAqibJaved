import FamilyData from "./AssignmentProps/FamilyData";
function App() {
  return <FamilyData />;
}
export default App;
